<?php
include 'connect.php';
if (isset($_POST['start'])) {

    $start = strtotime($_POST['start']);
    $end = strtotime($_POST['end']);
    $count = 0;
    while (date('Y-m-d', $start) < date('Y-m-d', $end)) {
        $count += date('N', $start) < 6 ? 1 : 0;
        $start = strtotime("+1 day", $start);
    }
    echo $count + 1;
}

if (isset($_POST['em'])) {
    $empid = $_POST['em'];
    $rendered = 0;
    $select = "SELECT * FROM emp_leaves WHERE EmployeeID='$empid' ORDER BY LeaveID DESC LIMIT 1";
    $selectq = mysqli_query($conn, $select);
    $row = mysqli_fetch_assoc($selectq);
    $rendered = $row['Remaining'];
    // if ($selectq) {
    //     while ($row = mysqli_fetch_assoc($selectq)) {
    //         $rendered += $row['TotalDays'];
    //     }
    // }

    // $rendered = 24 - $rendered;
    echo $rendered;
}


if (isset($_POST['sub'])) {
    $today = date('Y-m-d');
    $empidd = $_POST['emps'];
    $type = $_POST['type'];



    if ($type == 'Days') {
        $start = $_POST['start'];
        $end = $_POST['end'];
        $status = "";

        $start2 = strtotime($start);
        $end2 = strtotime($end);
        $tot = 0;

        //adding days except weekends
        while (date('Y-m-d', $start2) < date('Y-m-d', $end2)) {
            $tot += date('N', $start2) < 6 ? 1 : 0;
            $start2 = strtotime("+1 day", $start2);
        }
        $tot += 1;

        $getrem = "SELECT * FROM emp_leaves WHERE EmployeeID='$empidd' ORDER BY LeaveID DESC LIMIT 1";
        $getremq = mysqli_query($conn, $getrem);
        $j = mysqli_fetch_assoc($getremq);

        if ($j['Remaining'] == 0) {
            $remaining = 0;
            $status = "ADV";
            $ins1 = "INSERT INTO emp_leaves(EmployeeID, StartDate, EndDate, TotalDays, Remaining, DateRequested, Stats) VALUES('$empidd', '$start', '$end','$tot','$remaining','$today','$status')";
            $insq = mysqli_query($conn, $ins1);
            $_SESSION['message'] = "Leave filed successfully!";
            $_SESSION['status'] = "success";
            header('location: index.php');
        } else {
            $remaining = $j['Remaining'] - $tot;
            if ($remaining < 0) {
                $tot = $tot - abs($remaining);
                $status = "OK";
                // $remaining = 0;


                //ok status
                $ins1 = "INSERT INTO emp_leaves(EmployeeID, StartDate, EndDate, TotalDays, Remaining, DateRequested, Stats) VALUES('$empidd', '$start', '$end','$tot',0,'$today','$status')";
                $insq = mysqli_query($conn, $ins1);

                //for advance leave (lumabis na leave)
                $status = "ADV";
                $tot = abs($remaining);
                $add = "INSERT INTO emp_leaves(EmployeeID, StartDate, EndDate, TotalDays, Remaining, DateRequested, Stats) VALUES('$empidd', '$start', '$end','$tot',0,'$today','$status')";
                $addq = mysqli_query($conn, $add);
                $_SESSION['message'] = "Leave filed successfully!";
                $_SESSION['status'] = "success";
                header('location: index.php');
            } else {
                $status = "OK";
                $add = "INSERT INTO emp_leaves(EmployeeID, StartDate, EndDate, TotalDays, Remaining, DateRequested, Stats) VALUES('$empidd', '$start', '$end','$tot','$remaining','$today','$status')";
                $addq = mysqli_query($conn, $add);
                $_SESSION['message'] = "Leave filed successfully!";
                $_SESSION['status'] = "success";
                header('location: index.php');
            }
        }
    } else if ($type == 'Half') {
        $date = $_POST['start2'];
        $getrem = "SELECT * FROM emp_leaves WHERE EmployeeID='$empidd' ORDER BY LeaveID DESC LIMIT 1";
        $getremq = mysqli_query($conn, $getrem);
        $j = mysqli_fetch_assoc($getremq);
        if ($j['Remaining'] == 0) {
            $remaining = 0;
            $status = "ADV";
        } else {
            $remaining = $j['Remaining'] - 0.5;
            $status = "OK";
        }


        $ins2 = "INSERT INTO emp_leaves(EmployeeID, StartDate, EndDate, TotalDays, Remaining, DateRequested, Stats) VALUES('$empidd', '$date', '$date', 0.5, '$remaining','$today', '$status')";
        $insq2 = mysqli_query($conn, $ins2);
        $_SESSION['message'] = "Leave filed successfully!";
        $_SESSION['status'] = "success";
        header('location: index.php');
    }
}

if (isset($_POST['name'])) {
    $name = $_POST['name'];
    $x = 0;
    $g = "SELECT  x.EmployeeID, x.Stats, x.StartDate, x.Remaining, x.EndDate, x.TotalDays, e.FirstName, e.LastName, j.Position, d.Department
    FROM emp_leaves x
    INNER JOIN employee e
    ON x.EmployeeID=e.EmployeeID
    INNER JOIN jobs j
    ON j.JobID=e.JobID
    INNER JOIN department d
    ON d.DepartmentID=j.DepartmentID
    WHERE e.FirstName LIKE '%" . $name . "%'
    ORDER BY LeaveID DESC";

    $gq = mysqli_query($conn, $g);
    while ($k = mysqli_fetch_assoc($gq)) {
        $x++;
        if ($k['Stats'] == "OK") {
?>
            <tr>
                <td><?php echo $x; ?></td>
                <td><?php echo $k['FirstName'] . " " . $k['LastName']; ?></td>
                <td><?php echo $k['StartDate'] . " to " . $k['EndDate']; ?></td>
                <td><?php echo $k['TotalDays']; ?></td>
                <td><?php echo $k['Remaining']; ?></td>
            </tr>
        <?php } else {
        ?>
            <tr class="table-warning">
                <td><?php echo $x; ?></td>
                <td><?php echo $k['FirstName'] . " " . $k['LastName']; ?></td>
                <td><?php echo $k['StartDate'] . " to " . $k['EndDate']; ?></td>
                <td><?php echo $k['TotalDays']; ?></td>
                <td><?php echo $k['Remaining']; ?></td>
            </tr>
<?php }
    }
}
