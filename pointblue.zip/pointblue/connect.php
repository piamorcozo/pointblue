<?php
session_start();

$errors = array();
$servername = "localhost";
$username = "root";
$password = "";
$db = "pointblue";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);
