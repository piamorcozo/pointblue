<?php include 'connect.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/logos.png">
    <link rel="icon" type="image/png" href="./assets/img/logos.png">

    <title>Leave Form
    </title>
    <?php include 'header.php'; ?>
</head>

<!-- <body style="background-image: url(images/bg1.png);"> -->

<body class="">

    <main class="">
        <section>
            <div class="page-header min-vh-100">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 ">
                            <div class="card shadow-small">
                                <div class="card-header pb-0 text-start">
                                    <h4 class="font-weight-bolder">Leave Form</h4>

                                </div>
                                <div class="card-body">
                                    <form role="form" method="POST" action="backend.php">
                                        <div class="row">
                                            <label class="mb-0">Please select employee:</label>
                                            <div class="col-md-12 form-group">
                                                <!-- <label class="form-label">Name</label> -->
                                                <select class="form-select" name="emps" onchange="checkem(this)">
                                                    <?php
                                                    $getsub = "SELECT * FROM employee";
                                                    $getq = mysqli_query($conn, $getsub);
                                                    while ($s = mysqli_fetch_assoc($getq)) {
                                                    ?>
                                                        <option name="" value="<?php echo $s['EmployeeID']; ?>"><?php echo $s["FirstName"] . ' ' . $s["LastName"]; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>

                                        </div>
                                        <div id="available">
                                            <div id="availablex">

                                            </div>

                                            <br>

                                            <div class="row">
                                                <div class="col-md-12 form-group">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" onclick="f1(this)" name="type" id="type1" value="Days">
                                                        <label class="form-check-label">
                                                            Days
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" onclick="f1(this)" name="type" id="type2" value="Half">
                                                        <label class="form-check-label">
                                                            Half Day
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div id="days">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="start" class="form-control-label">Start Date</label>
                                                        <input class="form-control" type="date" onchange="date2(this)" name="start" id="start">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="end" class="form-control-label">End Date</label>
                                                        <input class="form-control" type="date" onchange="date(this)" name="end" id="end">
                                                    </div>
                                                </div>
                                            </div>
                                            <label id="missingstart" style="color:chocolate"><i>Please select Start Date.</i></label>
                                            <label id="invaliddate" style="color:chocolate"><i>Start date can't be greater than End date.</i></label>
                                            <div class="row" id="totalleave">
                                                <!-- <div class="col-md-6">
                                                    <label>Leave Requested:</label>
                                                </div>
                                                <div class="col-md-6">
                                                    <label>Leave Balance:</label>
                                                </div> -->
                                            </div>

                                        </div>

                                        <div id="hours">
                                            <div class="row">
                                                <div class="form-group">
                                                    <label for="start" class="form-control-label">Date</label>
                                                    <input class="form-control" type="date" onchange="df(this)" name="start2" id="start2">
                                                </div>
                                            </div>
                                            <div id="halfdiv">

                                            </div>

                                        </div>




                                        <div class="text-center">
                                            <button type="submit" name="sub" id="sub" class="btn btn-lg btn-primary btn-lg w-100 mt-4 mb-0">Submit</button>

                                        </div>
                                    </form>
                                </div>
                                <!-- <div class="card-footer text-center pt-0 px-lg-2 px-1">
                                    <p class="mb-4 text-sm mx-auto">
                                        Nevermind.
                                        <a href="index.php" class="text-primary text-gradient font-weight-bold">Login now</a>
                                    </p>
                                </div> -->
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 ">
                            <div class="card  shadow-sm" style="background-color:transparent">
                                <div class="card-body">
                                    <div class="input-group mb-3">
                                        <span class="input-group-text " id="basic-addon1"><i class="fa fa-search"></i></span>
                                        <input type="text" onkeyup="searchfunc(this)" class="form-control " placeholder="Search Employee" aria-describedby="basic-addon1">
                                    </div>
                                    <div class="table-responsive" id="defaulttbl">
                                        <table id="" class="table table-hover nowrap table-bordered">
                                            <thead class="table-dark" style="font-size:small;">
                                                <tr>
                                                    <th>No.</th>
                                                    <th>Employee</th>
                                                    <th>Date</th>
                                                    <th>Total Days</th>
                                                    <th>Remaining Leaves</th>

                                                </tr>
                                            </thead>
                                            <tbody style="font-size:small;">
                                                <?php
                                                $x = 0;
                                                $rem = 24;
                                                $get = "SELECT  x.EmployeeID, x.Stats, x.StartDate, x.Remaining, x.EndDate, x.TotalDays, e.FirstName, e.LastName, j.Position, d.Department
                                                            FROM emp_leaves x
                                                            INNER JOIN employee e
                                                            ON x.EmployeeID=e.EmployeeID
                                                            INNER JOIN jobs j
                                                            ON j.JobID=e.JobID
                                                            INNER JOIN department d
                                                            ON d.DepartmentID=j.DepartmentID
                                                            ORDER BY LeaveID DESC";
                                                $getq = mysqli_query($conn, $get);
                                                while ($k = mysqli_fetch_assoc($getq)) {
                                                    $x++;
                                                    if ($k['Stats'] == "OK") {
                                                ?>
                                                        <tr>
                                                            <td><?php echo $x; ?></td>
                                                            <td><?php echo $k['FirstName'] . " " . $k['LastName']; ?></td>
                                                            <td><?php echo $k['StartDate'] . " to " . $k['EndDate']; ?></td>
                                                            <td><?php echo $k['TotalDays']; ?></td>
                                                            <td><?php echo $k['Remaining']; ?></td>
                                                        </tr>
                                                    <?php } else {
                                                    ?>
                                                        <tr class="table-warning">
                                                            <td><?php echo $x; ?></td>
                                                            <td><?php echo $k['FirstName'] . " " . $k['LastName']; ?></td>
                                                            <td><?php echo $k['StartDate'] . " to " . $k['EndDate']; ?></td>
                                                            <td><?php echo $k['TotalDays']; ?></td>
                                                            <td><?php echo $k['Remaining']; ?></td>
                                                        </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="table-responsive" id="filteredtbl">
                                        <table id="" class="table table-hover nowrap table-bordered">
                                            <thead class="table-dark" style="font-size:small;">
                                                <tr>
                                                    <th>No.</th>
                                                    <th>Employee</th>
                                                    <th>Date</th>
                                                    <th>Total Days</th>
                                                    <th>Remaining Leaves</th>

                                                </tr>
                                            </thead>
                                            <tbody id="tbl2" style="font-size:small;">
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            </div>
        </section>
    </main>
    <!--   Core JS Files   -->
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../assets/js/argon-dashboard.min.js?v=2.0.4"></script>
</body>
<!--   Core JS Files   -->
<script src="./assets/js/core/popper.min.js"></script>
<script src="./assets/js/core/bootstrap.min.js"></script>
<script src="./assets/js/plugins/perfect-scrollbar.min.js"></script>
<script src="./assets/js/plugins/smooth-scrollbar.min.js"></script>
<script src="./assets/js/plugins/chartjs.min.js"></script>
<script src="./assets/js/sweetalert2.js"></script>
<!-- <script src="sweetalert2.all.min.js"></script> -->
<script>
    $("#days").hide();
    $("#hours").hide();
    $("#missingstart").hide();
    $("#invaliddate").hide();
    $("#totalleave").hide();
    $("#available").hide();
    $("#filteredtbl").hide();
    document.getElementById("sub").disabled = true;

    $('#tbl1').DataTable({
        responsive: true
    });
    var current;
    var availabledays = 0;
    var leaverequest;

    //function for search table
    function searchfunc(vals) {
        var name = vals.value;
        //document.getElementById("filteredtbl").innerHTML = "";
        if (name != "") {

            $.ajax({
                url: "backend.php",
                method: "POST",
                data: {
                    name: name
                },
                success: function(data) {
                    var res = data;
                    $("#defaulttbl").hide();
                    $("#filteredtbl").show();

                    $("#tbl2").html(data);
                }
            });
        } else {
            //document.getElementById("filteredtbl").innerHTML = "";
            $("#filteredtbl").hide();
            $("#defaulttbl").show();
        }

    }
    //function for checking if half day date is not empty
    function df(x) {
        if (!x.value) {
            document.getElementById("sub").disabled = true;
        } else {
            document.getElementById("sub").disabled = false;
        }
    }
    //function for checking employee's available leaves
    function checkem(em) {
        $("#available").show();
        availabledays = 0;
        $("#hours").hide();
        $("#days").hide();

        current = new Date();
        current = current.getMonth();
        current++;
        current = current * 2;

        $.ajax({
            url: "backend.php",
            method: "POST",
            data: {
                em: em.value
            },
            success: function(data) {
                availabledays = data;
                document.getElementById("availablex").innerHTML = "";
                if (availabledays == 0) {
                    var inn = `<div class="row"><label style="color:chocolate"><i>You have no remaining leave days left. Filing another will serve
                     as an unpaid leave.</i></label></div>`;
                    $("#availablex").append(inn);
                } else {
                    var neww = `<div class="row">
                                                <div class="col-md-6">
                                                    <p class="mb-0">Available days: <b>` + availabledays + ` days</b></p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p class="mb-0">Pro-rated accumulate leave: <b>` + current + ` days</b></p>
                                                </div>
                                            </div>`;
                    $("#availablex").append(neww);
                }



            }
        });
    }
    //function for choosing halfday or >=1 day
    function f1(vals) {
        if (vals.value == "Half") {
            if (availabledays == 0) {
                var newd = `<div class="row">
                            <div class="col-md-6">
                               <p>Leave Requested: <b>4 hours</b></p>
                            </div>
                            <div class="col-md-6">
                                <p>Leave Balance: <b>` + 0 + ` days</b></p>
                            </div>
                        </div>`;
                document.getElementById("halfdiv").innerHTML = "";

                $("#halfdiv").append(newd);
            } else {
                var balance = availabledays - 0.5;
                var newd = `<div class="row">
                            <div class="col-md-6">
                               <p>Leave Requested: <b>4 hours</b></p>
                            </div>
                            <div class="col-md-6">
                                <p>Leave Balance: <b>` + balance + ` days</b></p>
                            </div>
                        </div>`;
                document.getElementById("halfdiv").innerHTML = "";

                $("#halfdiv").append(newd);
            }
            $("#hours").show();
            $("#days").hide();

        } else if (vals.value == "Days") {
            $("#days").show();
            $("#hours").hide();
        }
    }

    //function for choosing start and end date
    function date(end) {
        // alert(s.value);
        var start = document.getElementById('start');
        if (!start.value) {
            //show please select start date
            $("#missingstart").show();
            document.getElementById("sub").disabled = true;
        } else {

            //check if start < end
            var d1 = new Date(start.value);
            var d2 = new Date(end.value);
            if (d1 > d2) {
                $("#invaliddate").show();
                document.getElementById("totalleave").innerHTML = "";
                document.getElementById("sub").disabled = true;
            } else {
                $("#invaliddate").hide();
                document.getElementById("sub").disabled = false;

                //ajax to compute leave balance and requested
                $.ajax({
                    url: "backend.php",
                    method: "POST",
                    data: {
                        start: start.value,
                        end: end.value
                    },
                    success: function(data) {
                        leaverequest = data;
                        if (availabledays == 0) {
                            document.getElementById("totalleave").innerHTML = "";
                            $("#totalleave").show();

                            var newd = `<div class='col-md-6' id="1">
                                                    <p>Leave Requested: <b>` + leaverequest + ` days</b></p>
                                                </div>
                                                <div class='col-md-6'>
                                                    <p>Leave Balance: <b>` + 0 + ` days</b></p>
                                                </div>`;

                            $("#totalleave").append(newd);
                        } else {

                            var balance = availabledays - leaverequest;
                            document.getElementById("totalleave").innerHTML = "";
                            $("#totalleave").show();

                            var newd = `<div class='col-md-6' id="1">
                                                    <p>Leave Requested: <b>` + leaverequest + ` days</b></p>
                                                </div>
                                                <div class='col-md-6'>
                                                    <p>Leave Balance: <b>` + balance + ` days</b></p>
                                                </div>`;

                            $("#totalleave").append(newd);
                        }
                    }
                });
            }




            $("#missingstart").hide();
        }
    }


    //function to hide warning on start date
    function date2(start) {
        $("#missingstart").hide();
        document.getElementById("sub").disabled = false;
        //check if start < end
        var end = document.getElementById('end');
        if (end.value) {
            var d1 = new Date(start.value);
            var d2 = new Date(end.value);
            if (d1 > d2) {
                $("#invaliddate").show();
                document.getElementById("totalleave").innerHTML = "";
                document.getElementById("sub").disabled = true;
            } else {
                $("#invaliddate").hide();
                document.getElementById("sub").disabled = false;

                $.ajax({
                    url: "backend.php",
                    method: "POST",
                    data: {
                        start: start.value,
                        end: end.value
                    },
                    success: function(data) {
                        leaverequest = data;
                        if (availabledays == 0) {
                            document.getElementById("totalleave").innerHTML = "";
                            $("#totalleave").show();

                            var newd = `<div class='col-md-6' id="1">
                                                    <p>Leave Requested: <b>` + leaverequest + ` days</b></p>
                                                </div>
                                                <div class='col-md-6'>
                                                    <p>Leave Balance: <b>` + 0 + ` days</b></p>
                                                </div>`;

                            $("#totalleave").append(newd);
                        } else {
                            var balance = availabledays - leaverequest;
                            document.getElementById("totalleave").innerHTML = "";
                            $("#totalleave").show();

                            var newd = `<div class='col-md-6' id="1">
                                                    <p>Leave Requested: <b>` + leaverequest + ` days</b></p>
                                                </div>
                                                <div class='col-md-6'>
                                                    <p>Leave Balance: <b>` + balance + ` days</b></p>
                                                </div>`;

                            $("#totalleave").append(newd);
                        }
                    }
                });

            }
        } else {
            document.getElementById("sub").disabled = true;
        }
    }


    $('#pwordc').keyup(function() {
        var search = $(this).val();
        if (search != $('#pword').val()) {
            $("#invalid").show();
            $("#reg").attr('disabled', true);

        } else {
            $("#invalid").hide();
            $("#reg").attr('disabled', false);
        }

    });

    $("#eye").on('click', function(event) {
        event.preventDefault();
        if ($('#showp input').attr("type") == "text") {
            $('#showp input').attr('type', 'password');
            $('#showp i').addClass("fa-eye-slash");
            $('#showp i').removeClass("fa-eye");
        } else if ($('#showp input').attr("type") == "password") {
            $('#showp input').attr('type', 'text');
            $('#showp i').removeClass("fa-eye-slash");
            $('#showp i').addClass("fa-eye");
        }
    });
</script>
<!-- Github buttons -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
<!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
<script src="./assets/js/argon-dashboard.min.js?v=2.0.4"></script>

<?php
if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
?>
    <script>
        Swal.fire({
            icon: "<?php echo $_SESSION['status']; ?>",
            text: "<?php echo $_SESSION['message']; ?>",

        });
    </script>
<?php

    unset($_SESSION['status']);
}

?>
</body>

</html>